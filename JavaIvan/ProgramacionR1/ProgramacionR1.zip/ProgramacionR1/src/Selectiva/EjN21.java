/*
 *Una compañía ha decidido dar a sus mejores empleados una bonificación por su desempeño. Esta 
bonificación se basa en dos criterios: 
-el número de horas extras trabajadas  
-el número de horas que el empleado ha estado ausente del trabajo.

La compañía ha determinado que se use la siguiente fórmula para determinar la bonificación: se restan dos 
tercios de las horas de ausencia a las horas extras trabajadas y se distribuye la bonificación de acuerdo 
con la siguiente tabla:
Resultado Bonificación
> 40 horas $200.000,oo
> 30 horas pero <= 40 horas $150.000,oo
> 20 horas pero <= 30 horas $100.000,oo
> 10 horas pero <= 20 horas $50.000,oo
<= 10 horas $20.000,oo
Elabore un algoritmo que permita determinar la bonificación que recibirá un empleado cualquiera de la
 compañía.
 */
package Selectiva;

import java.util.Scanner;

/**
 *
 * @author ivand
 */
public class EjN21 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.println("BONIFICACION A LOS MEJORES EMPLEADOS");
        System.out.println("Digite las horas extras trabajadas ");
        int Hextra = leer.nextInt();

        System.out.println("Digite el numero de horas ausentes");
        int Hausente = leer.nextInt();

        int Bono = calcularbonificacion(Hextra, Hausente);
        System.out.println("La bonificacion es:$" + Bono);
    }

    public static int calcularbonificacion(int Hextra, int Hausentes) {
        
        int Bono;

        int res = Hausentes - (2 * Hausentes / 3);

        if (res > 40) {
            Bono = 200000;
            return Bono;
        } else if (res > 30) {
            Bono = 150000;
            return Bono;
        } else if (res > 20) {
            Bono = 100000;
            return Bono;
        } else if (res > 10) {
            Bono = 50000;
            return Bono;
        } else {
            Bono = 20000;
        }

        return Bono;
        }
    }

    

