
package arrylist;
import java.util.ArrayList;
import java.util.Locale;
import javax.swing.*;

/**
 *
 * @author DIEGO ARMANDO
 */
public class Arrylist {
    public static void main(String [] args) {
             ArrayList<String> listaNombres = new ArrayList<>();
        int opcion;

        do {
            opcion = mostrarMenu();

            switch (opcion) {
                case 1:
                    agregarNombre(listaNombres);
                    break;
                case 2:
                    sustituirNombre(listaNombres);
                    break;
                case 3:
                    buscarNombre(listaNombres);
                    break;
                case 4:
                    eliminarNombre(listaNombres);
                    break;
                case 5:
                    imprimirNombres(listaNombres);
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } while (opcion != 6);
    }

    public static int mostrarMenu() {
        String menu = "Seleccione una opción:\n" +
                "1. Agregar nombre\n" +
                "2. Sustituir nombre\n" +
                "3. Buscar nombre\n" +
                "4. Eliminar nombre\n" +
                "5. Imprimir nombres\n" +
                "6. Salir";

        String opcionStr = JOptionPane.showInputDialog(null, menu, "Gestión de nombres", JOptionPane.PLAIN_MESSAGE);

        int opcion;
        try {
            opcion = Integer.parseInt(opcionStr);
        } catch (NumberFormatException e) {
            opcion = 0;
        }
        return opcion;
    }

    public static void agregarNombre(ArrayList<String> listaNombres) {
        String nombre = JOptionPane.showInputDialog(null, "Ingrese el nombre a agregar:", "Agregar nombre", JOptionPane.PLAIN_MESSAGE);
        if (nombre != null && !nombre.isEmpty()) {
            String nombremayus = nombre.toUpperCase(Locale.ROOT);
            
            if (!listaNombres.contains(nombremayus)) {
                listaNombres.add(nombremayus);
                JOptionPane.showMessageDialog(null, "Nombre agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "El nombre ya existe en la lista", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void sustituirNombre(ArrayList<String> listaNombres) {
        if (listaNombres.isEmpty()) {
            JOptionPane.showMessageDialog(null, "La lista de nombres está vacía", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombreActual = JOptionPane.showInputDialog(null, "Ingrese el nombre a sustituir:", "Sustituir nombre", JOptionPane.PLAIN_MESSAGE);
        if (nombreActual != null && !nombreActual.isEmpty()) {
            String nombreActualmayus = nombreActual.toUpperCase(Locale.ROOT);
            if (listaNombres.contains(nombreActualmayus)) {
                String nuevoNombre = JOptionPane.showInputDialog(null, "Ingrese el nuevo nombre:", "Sustituir nombre", JOptionPane.PLAIN_MESSAGE);
                if (nuevoNombre != null && !nuevoNombre.isEmpty()) {
                    String nuevoNombremayus = nuevoNombre.toUpperCase(Locale.ROOT);
                    listaNombres.set(listaNombres.indexOf(nombreActualmayus), nuevoNombremayus);
                    JOptionPane.showMessageDialog(null, "Nombre sustituido correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "El nombre no existe en la lista", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void buscarNombre(ArrayList<String> listaNombres) {
        if (listaNombres.isEmpty()) {
            JOptionPane.showMessageDialog(null, "La lista de nombres está vacía", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombreBuscar = JOptionPane.showInputDialog(null, "Ingrese el nombre a buscar:", "Buscar nombre", JOptionPane.PLAIN_MESSAGE);
        if (nombreBuscar != null && !nombreBuscar.isEmpty()) {
            String nombreBuscarmayus = nombreBuscar.toUpperCase(Locale.ROOT);
            if (listaNombres.contains(nombreBuscarmayus)) {
                JOptionPane.showMessageDialog(null, "El nombre " + nombreBuscar + " está en la lista", "Resultado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "El nombre" + nombreBuscar + " no existe en la lista", "Resultado", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    public static void eliminarNombre(ArrayList<String> listaNombres) {
        if (listaNombres.isEmpty()) {
            JOptionPane.showMessageDialog(null, "La lista de nombres está vacía", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombreEliminar = JOptionPane.showInputDialog(null, "Ingrese el nombre a eliminar:", "Eliminar nombre", JOptionPane.PLAIN_MESSAGE);
        if (nombreEliminar != null && !nombreEliminar.isEmpty()) {
            String nombreEliminarmayus = nombreEliminar.toUpperCase(Locale.ROOT);
            if (listaNombres.contains(nombreEliminarmayus)) {
                listaNombres.remove(nombreEliminarmayus);
                JOptionPane.showMessageDialog(null, "Nombre eliminado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "El nombre no existe en la lista", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void imprimirNombres(ArrayList<String> listaNombres) {
        if (listaNombres.isEmpty()) {
            JOptionPane.showMessageDialog(null, "La lista de nombres está vacía", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        StringBuilder nombres = new StringBuilder("Lista de nombres:\n");
        for (String nombre : listaNombres) {
            nombres.append(nombre).append("\n");
        }
        JOptionPane.showMessageDialog(null, nombres.toString(), "Nombres", JOptionPane.INFORMATION_MESSAGE);
    
    }
    
}
        
         
