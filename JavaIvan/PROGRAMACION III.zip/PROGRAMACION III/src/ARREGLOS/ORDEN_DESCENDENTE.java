
package ARREGLOS;

import javax.swing.JOptionPane;

// EJERCICIO 12 
public class ORDEN_DESCENDENTE {
    public static void main(String[] args) {
         int a[];
        int n,aux=0;
        
        n=Integer.parseInt(JOptionPane.showInputDialog("dijite n elemtos"));
        
        a = new int [n];
        
        for (int i = 0; i < a.length; i++) {
            a[i] = Integer.parseInt(JOptionPane.showInputDialog("valores del vector"));
        }
            for (int i = 0; i < a.length-1; i++) {
                for (int j = i+1; j < a.length-1; j++) {
                    if (a[i] < a[j]) {
                        aux =a[i];
                        a[i]=a[j];
                        a[j] = aux;
                    }
                }
        }
            for (int i = 0; i < a.length; i++) {
                System.out.println(a[i]);
        }
    }
}
