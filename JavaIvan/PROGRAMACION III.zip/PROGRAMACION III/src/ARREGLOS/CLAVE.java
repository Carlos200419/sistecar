
package ARREGLOS;

import javax.swing.JOptionPane;

//EJERCICIO 5 
public class CLAVE {
    public static void main(String[] args) {
        int n;
        String nombre[];
        String clave;
        
        n = Integer.parseInt(JOptionPane.showInputDialog("dijite numero de elementos: "));
        
        nombre = new String [n];
        
        for (int i = 0; i < nombre.length; i++) {
            nombre [i] = JOptionPane.showInputDialog("nombre del usuario");
        }
        clave = JOptionPane.showInputDialog("dijite clave");
        int c=0;
        for (int i = 0; i < nombre.length; i++) {
            if(nombre[i].equalsIgnoreCase(clave)){
                c++;
        }
            
        }
        if(c!=0)
                 JOptionPane.showMessageDialog(null, "la clave "+ clave +" se encontro "+c );
            else 
                JOptionPane.showMessageDialog(null,"no se encontro la clave");
    }
}
