
package ARREGLOS;

import javax.swing.JOptionPane;

public class BUSQUEDA {
    public static void main(String[] args) {
        int bu1,n,i,cont=0;
        
        n=Integer.parseInt(JOptionPane.showInputDialog("cantidad de elementos"));
        bu1=Integer.parseInt(JOptionPane.showInputDialog(" cual es el valor a buscar"));
        
        int arreglo[] = new int [n];
        
        for(i=0;i<arreglo.length;i++){
            
            arreglo[i]=Integer.parseInt(JOptionPane.showInputDialog("valor del elemento"));
            
            if(arreglo[i] == bu1){
                cont++;
            }
        }
        JOptionPane.showMessageDialog(null,"el valor a buscar es "+bu1+" y se encontro el numero " + cont+ " veces  ");
    }
}
