/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ARREGLOS;

import javax.swing.JOptionPane;

/**
 *
 * @author WILL2013
 */
public class IMPAR {
    public static void main(String[] args) {
        int numeros [];
        int n;
        do{
    n = Integer.parseInt(JOptionPane.showInputDialog("dijite numeros"));
    }
        while(n<1);
        numeros = new int [n];
        
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("dijite un valor ");
            
            numeros [i] = Integer.parseInt(JOptionPane.showInputDialog("dijite nuemro en la pocion "+i));
        }
        for (int p = 0; p < numeros.length; p++) {
            if (numeros [p]%2 == 1) {
                numeros[p] = 0;
            }
        }
        for (int x = 0; x < numeros.length; x++) {
            JOptionPane.showMessageDialog(null, "el valor en la pocision "+x+" es: "+numeros [x]);
        }
    }
}
