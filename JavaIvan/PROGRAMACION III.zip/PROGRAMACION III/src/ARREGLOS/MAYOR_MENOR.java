
package ARREGLOS;

import javax.swing.JOptionPane;

// EJERCICI 8 
public class MAYOR_MENOR {
    public static void main(String[] args) {
        int a[];
        int n;
        
        n= Integer.parseInt(JOptionPane.showInputDialog("dijite elementos"));
        
        a = new int [n];
        
        for (int i = 0; i < a.length; i++) {
            a[i]= Integer.parseInt(JOptionPane.showInputDialog((i+1)+". valor del arreglo"));
        }
        int mayor=a[0];
        int menor=a[0];
        
        for (int i = 0; i < a.length; i++) {
            if(a[i]>mayor){
                mayor=a[i];
            }else{
                if(a[i]<menor){
                    menor=a[i];
                }
                    
            }
        }
        JOptionPane.showMessageDialog(null,"el numero mayor es: "+ mayor);
        JOptionPane.showMessageDialog(null, "el numero menor del arreglo es: "+ menor);
        
    }
}
