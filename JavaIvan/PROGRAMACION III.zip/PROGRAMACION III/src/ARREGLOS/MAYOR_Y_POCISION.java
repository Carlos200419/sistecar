
package ARREGLOS;

import javax.swing.JOptionPane;

// EJERCICIO 9
public class MAYOR_Y_POCISION {
    public static void main(String[] args) {
          int a[];
        int n;
        
        n= Integer.parseInt(JOptionPane.showInputDialog("numero de elemtos"));
        
         a = new int [n];
         
         for (int i = 0; i < a.length; i++) {
            a[i]=Integer.parseInt(JOptionPane.showInputDialog((i+1)+". dijite valor del arreglo"));
        }
         mayorposicion(a);
         
    }
    public static void mayorposicion(int a[]){
         int mayor=0;
         int posicion=0;
         for (int i = 0; i < a.length; i++) {
            if(a[i]>mayor){
                mayor=a[i];
                posicion=i;
            }
        }
         JOptionPane.showMessageDialog(null," el numero mayor del arreglo es: " + mayor);
         JOptionPane.showMessageDialog(null,"su posicion del arreglo es: " + posicion);
    }
}
