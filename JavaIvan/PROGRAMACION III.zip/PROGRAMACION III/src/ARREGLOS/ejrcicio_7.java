/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ARREGLOS;

import javax.swing.JOptionPane;

/**
 *
 * @author Sala de Sistemas
 */
public class ejrcicio_7 {
    public static void main(String[] args) {
        int a[], b[],c[],e[],d[];
        int n;
        n = Integer.parseInt(JOptionPane.showInputDialog("dijite tamaño del arreglo"));
        
        a=new int [n]; b = new int[n]; c = new int [n];
        e = new int [n/2];
        
        
        for ( int i = 0; i < a.length; i++) {
            a[i]=  Integer.parseInt(JOptionPane.showInputDialog("llenar el vector a "));
        }
        for ( int i = 0; i < b.length; i++) {
              b[i]=  Integer.parseInt(JOptionPane.showInputDialog("llenar el vector b "));
        }
        
        for ( int i = 0; i < a.length; i++) {
            c[i]=a[i]+b[i];
                    JOptionPane.showMessageDialog(null, "resultado de la suma " +c[i]);
        }
        if (n%2!=0)
            d = new int [(n+1)/2];
        else
            d = new int [n/2];
       
    
      int k=0;
        for ( int i = 0; i < a.length; i=i+2) {
            d[k]= a[i]-b[i];
            k++;
        }
        int j=0;
        for ( int i = 1; i < a.length; i=i+2) {
            e[j]= a[i]*b[i];
            j++;
        }
        
        
        for ( int i= 0; k < a.length; k++) {
            JOptionPane.showMessageDialog(null,"resultado de la resta del vector  "+d[i]);
        }
        for ( int i = 0; j < a.length; j++) {
            JOptionPane.showMessageDialog(null, "resultado del producto "+e[i]);
        }
    }
}
