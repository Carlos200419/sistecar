/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ARREGLOS;

import javax.swing.JOptionPane;

/**
 *
 * @author Biblioteca
 */
public class ejercicio_11 {
    public static void main(String[] args) {
        int v[];
        int n;
        
        n = Integer.parseInt(JOptionPane.showInputDialog("numeros de elementos en el vector"));
        
        v = new int [n];
        
        for (int i = 0; i < v.length; i++) {
            v[i] = Integer.parseInt(JOptionPane.showInputDialog("llena el vector en la posicion cero "+i));
            
            System.out.println("vector: "+v[i]);
        }
        int rep = 0;
        int k=0;
        for (int i = 0; i < v.length; i++) {
            if(v[i]==v[k])
                rep++;
        }
        int par=0;
        int imp=0;
        
        for (int i = 0; i < v.length; i++) {
            if (v[i]%2==0) {
                par++;
            }else
                imp++;
        }
        System.out.println("valores repetidos: "+rep);
        System.out.println("valores pares: "+par);
        System.out.println("valores impares: "+imp);
    }
}
