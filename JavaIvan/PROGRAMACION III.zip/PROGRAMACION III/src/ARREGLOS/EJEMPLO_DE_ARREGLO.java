/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ARREGLOS;

/**
 *
 * @author WILL2013
 */
public class EJEMPLO_DE_ARREGLO {
    public static void main(String[] args) {
        //        int dias_del_mes [] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
//        System.out.println("Abril tiene " + dias_del_mes [3] +" días.");

// puede ser de las dos formas //

        int dias_del_mes [];
        dias_del_mes =new int[12];
        dias_del_mes [0] = 31;
        dias_del_mes [1] = 28;
        dias_del_mes [2] = 31;
        dias_del_mes [3] = 30;
        dias_del_mes [4] = 31;
        dias_del_mes [5] = 30;
        dias_del_mes [6] = 31;
        dias_del_mes [7] = 31;
        dias_del_mes [8] = 30;
        dias_del_mes [9] = 31;
        dias_del_mes [10] = 30;
        dias_del_mes [11] = 31;
        
        System.out.println("Abril tiene " + dias_del_mes [3] + " días.");

    }
}
