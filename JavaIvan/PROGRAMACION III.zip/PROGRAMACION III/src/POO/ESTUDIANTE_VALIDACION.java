/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POO;

import javax.swing.JOptionPane;

/**
 *
 * @author Biblioteca
 */
public class ESTUDIANTE_VALIDACION {
    public static void main(String[] args) {
         Estudiantes t1,t2;
       
       String codigo, id, nombre, apellido;
       int edad;
       float promedio;
       
       //AQUI EMPIEZA EL PRIMER CONSTRUCTOR
            t1 = new Estudiantes();//PRIMER CONTRUCTOR
            
       id = JOptionPane.showInputDialog("Digite id del estudiante");
       codigo = JOptionPane.showInputDialog("Digite codigo del estudiante");
       nombre =JOptionPane.showInputDialog("Digite nombre del estudiante");
       apellido =JOptionPane.showInputDialog("Digite apellido del estudiante");
       promedio  = Float.parseFloat(JOptionPane.showInputDialog("Digite promedio del estudiante"));
       edad  = Integer.parseInt(JOptionPane.showInputDialog("Digite edad del estudiante"));
       
       t1.setId(id);
       t1.setCodigo(codigo);
       t1.setNombre(nombre);
       t1.setApellido(apellido);
       t1.setEdad(edad);
       t1.setPromedio(promedio);

       JOptionPane.showMessageDialog(null, t1.mostrardatos());
       t1.semestre();
       t1.jurado();
//////////////////////////////////////////////////////////////////////////////////////////////       
       
       
// AQUI EMPIEZA EL SEGUNDO CONSTRUCTOR    
       id = JOptionPane.showInputDialog("Digite id del estudiante");
       codigo = JOptionPane.showInputDialog("Digite codigo del estudiante");
       nombre =JOptionPane.showInputDialog("Digite nombre del estudiante");
       apellido =JOptionPane.showInputDialog("Digite apellido del estudiante");
       promedio  = Float.parseFloat(JOptionPane.showInputDialog("Digite promedio del estudiante"));
       edad  = Integer.parseInt(JOptionPane.showInputDialog("Digite edad del estudiante"));
       
    t2= new Estudiantes(id,nombre,apellido,codigo,edad,promedio); // SEGUNDO COSNTRUCTOR

      JOptionPane.showMessageDialog(null, t2.mostrardatos());
       t2.semestre();
       t2.jurado();
    }
}
