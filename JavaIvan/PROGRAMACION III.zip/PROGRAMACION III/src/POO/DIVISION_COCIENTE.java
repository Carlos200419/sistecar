/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POO;
//19. Elabore un algoritmo que lea dos números e imprima el cociente entre el primero y el segundo. Si el
//segundo es cero no ejecute el caso sino que muestre el mensaje: ‘la división no es posible’.

import javax.swing.JOptionPane;

public class DIVISION_COCIENTE {
    public static void main(String[] args) {
        Numero N1 = new Numero();
        
        N1.n1 = Integer.parseInt(JOptionPane.showInputDialog("dijite primer numero"));
        N1.n2 = Integer.parseInt(JOptionPane.showInputDialog("dijite segundo numero"));
        
        
        JOptionPane.showMessageDialog(null, N1.mostrar());
        N1.division();
    }
}
