
package POO;

import javax.swing.JOptionPane;

public class Numero {
    int  n1 , n2;
    
    public void division(){
        int resultado=0;
        if(n2!=0){
            resultado = n1/n2;
            JOptionPane.showMessageDialog(null,"resultado entre " +n1+ " y " +n2+" es: " +resultado);
        }else
            JOptionPane.showMessageDialog(null,"no se puede mostrar ");
        
    }
    
    public String mostrar(){
        String M;
        
        M = "numero uno: "+n1+" y numero 2 : "+n2;
        return M;
    }
}
