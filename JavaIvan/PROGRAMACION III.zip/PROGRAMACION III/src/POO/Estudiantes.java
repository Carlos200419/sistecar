/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package POO;

import javax.swing.JOptionPane;

public class Estudiantes {
   private String id, nombre,apellido,codigo;
     private int edad;
   private float promedio;

    public Estudiantes(String id, String nombre, String apellido, String codigo, int edad, float promedio) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.codigo = codigo;
        this.edad = edad;
        this.promedio = promedio;
    }

    public Estudiantes() {
        
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getPromedio() {
        return promedio;
    }

    public void setPromedio(float promedio) {
        this.promedio = promedio;
    }
    
    public void jurado(){
        if(edad >=18){
            JOptionPane.showMessageDialog(null,"si puede votar");
        }
        else
            JOptionPane.showMessageDialog(null,"no puede votar");
    }
    public void semestre(){
        if(promedio>=3){
            JOptionPane.showMessageDialog(null, " semestre aprovado");
        }else
            JOptionPane.showMessageDialog(null,"semestre reprobado");
    }
    public String mostrardatos(){
        String n;
         return n = "su nombre es "+nombre+" su apellido es "+apellido+" edad "+edad+"\n"+
                 "su promedio de notas es "+promedio+" id es "+id+" y su codigo es "+codigo;
    }
}
