/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JFRAME;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Principal extends JFrame implements ActionListener {
    JLabel tituloLabel, nombreLabel, codigoLabel, asignaturaLabel,quizLabel,parcialLabel,tallerLabel,expocisionLabel;
    JTextField nombreText,asignaturaText,codigoText, quizText, parcialText, tallerText,expocisionText;
    JTextArea salidaText;
    JButton limpiarButton, mostrarButton;
    JScrollPane desplaza;

    
     public static void main(String[] args) {
        Principal ejercicio = new Principal();
        ejercicio.setVisible(true);
    }
     public Principal() {
        super("Aplicación Estudiante");

        tamaniosVentana();
    }
     private void tamaniosVentana(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); 
        setResizable(false); 
        setLocationRelativeTo(null);
        setSize(500, 330); 
        
        tituloLabel = new JLabel("CALCULO DEFINITIVA DEL ESTUDIANTE");
        tituloLabel.setBounds(120, 10, 350, 25); // coordenadas (x, y, tamañox, tamañoy)
        add(tituloLabel); // agregar el componente a la interfaz

        // campos de la interfaz
        nombreLabel = new JLabel("Nombre y apellido:");
        nombreLabel.setBounds(20, 40, 200, 25);
        add(nombreLabel);

        nombreText = new JTextField(20);
        nombreText.setBounds(140, 40, 150, 25);
        add(nombreText);
        
         asignaturaLabel = new JLabel("Nombre asignatura:");
        asignaturaLabel.setBounds(20, 70, 200, 25);
        add(asignaturaLabel);

        asignaturaText = new JTextField(20);
        asignaturaText.setBounds(140, 70, 150, 25);
        add(asignaturaText);
        
         codigoLabel = new JLabel("Codigo:");
        codigoLabel.setBounds(20, 100, 200, 25);
        add(codigoLabel);

        codigoText = new JTextField(20);
        codigoText.setBounds(140, 100, 150, 25);
        add(codigoText);
        
        quizLabel = new JLabel("Quiz:");
        quizLabel.setBounds(20, 140, 70, 25);
        add(quizLabel);

        quizText = new JTextField(20);
        quizText.setBounds(50, 140, 50, 25);
        add(quizText);
        
        tallerLabel = new JLabel("Taller:");
        tallerLabel.setBounds(100, 140, 70, 25);
        add(tallerLabel);

        tallerText = new JTextField(20);
        tallerText.setBounds(140, 140, 50, 25);
        add(tallerText);
        
        parcialLabel = new JLabel("Parcial:");
        parcialLabel.setBounds(190, 140, 50, 25);
        add(parcialLabel);

        parcialText = new JTextField(20);
        parcialText.setBounds(240, 140, 50, 25);
        add(parcialText);
        
        expocisionLabel = new JLabel("Expocision:");
        expocisionLabel.setBounds(290, 140, 70, 25);
        add(expocisionLabel);

        expocisionText = new JTextField(20);
        expocisionText.setBounds(360, 140, 50, 25);
        add(expocisionText);
        
        //BOTONES
        mostrarButton = new JButton("Mostrar");
        mostrarButton.setMnemonic('M');
        mostrarButton.setBounds(120, 170, 100, 25);
        mostrarButton.addActionListener(this);
        add(mostrarButton);

        limpiarButton = new JButton("Limpiar");
        limpiarButton.setMnemonic('L');
        limpiarButton.setBounds(250, 170, 100, 25);
        limpiarButton.addActionListener(this);
        add(limpiarButton);
        
         salidaText = new JTextArea();
        salidaText.setFont(new Font("Trebuchet MS", 0, 12));
        salidaText.setEditable(false);

        desplaza = new JScrollPane(salidaText);
        desplaza.setBounds(20, 200, 450, 110);
        add(desplaza);

    }
     public void actionPerformed(ActionEvent e) {
        //Si se presiona el botón llamado calcularButton
        if (e.getSource() == mostrarButton) {
            //Declaración de variables
            Estudiante e1 = new Estudiante();
            e1.setNombre(nombreText.getText());
            e1.setAsignatura(asignaturaText.getText());
            e1.setCodigo(Integer.parseInt(codigoText.getText()));
            e1.setQuiz(Double.parseDouble(quizText.getText()));
            e1.setTaller(Double.parseDouble(tallerText.getText()));
            e1.setParcial(Double.parseDouble(parcialText.getText()));
            e1.setExpocision(Double.parseDouble(expocisionText.getText()));
            
            //Salida
            salidaText.setText(e1.imprimir());
        }
        //Si se presiona el botón llamado limpiarButton
        if (e.getSource() == limpiarButton) {
            nombreText.setText("");
            asignaturaText.setText("");
            codigoText.setText("");
            quizText.setText("");
            tallerText.setText("");
            parcialText.setText("");
            expocisionText.setText("");
            salidaText.setText("");

            nombreText.requestFocus();
}
}
}
