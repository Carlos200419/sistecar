/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JFRAME;

/**
 *
 * @author Biblioteca
 */
public class Estudiante {
     private String nombre,asignatura;
    private int codigo;
    private double parcial,taller,expocision,quiz,definitiva;
    //constructor vacio
    public Estudiante() {
        this.parcial = 0.0d;
        this.taller = 0.0d;
        this.expocision = 0.0d;
        this.quiz = 0.0d;
        this.definitiva = 0.0d;
        this.nombre=null;
        this.asignatura=null;
        this.codigo=0;
    }
    // set y get

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    public double getParcial() {
        return parcial;
    }

    public void setParcial(double parcial) {
        this.parcial = parcial;
    }

    public double getTaller() {
        return taller;
    }

    public void setTaller(double taller) {
        this.taller = taller;
    }

    public double getExpocision() {
        return expocision;
    }

    public void setExpocision(double expocision) {
        this.expocision = expocision;
    }

    public double getQuiz() {
        return quiz;
    }

    public void setQuiz(double quiz) {
        this.quiz = quiz;
    }

    public double getDefinitiva() {
        return definitiva;
    }

    public void setDefinitiva(double definitiva) {
        this.definitiva = definitiva;
    }
    
    public double def(){
        definitiva = parcial*0.5 + taller*0.2 + expocision*0.15 + quiz*0.15;
        return definitiva;
    }
    public String validacionnota(){
        if (def()>=3.0) {
            return "aprovado";
        }else{
            return "reprovado";
        }
    }
    public String nota_mas_alta(){
        if (quiz>=taller && quiz>=parcial && quiz>=expocision) {
            return "quiz es la nota mas alta: "+quiz;
        }else{}
        if (taller>=quiz && taller>=parcial && taller>=expocision) {
            return "taller es la nota mas alta: "+taller;
        }else{}
        if (parcial>=taller && parcial>=quiz && parcial>=expocision) {
            return"parcial es la nota mas alta: "+parcial;
        }else{
            return"expocision es la nota mas alta: "+expocision;
       }
    }
     public String nota_mas_baja(){
        if (quiz<=taller && quiz<=parcial && quiz<=expocision) {
            return "quiz es la nota mas baja: "+quiz;
        }else{}
        if (taller<=quiz && taller<=parcial && taller<=expocision) {
            return "taller es la nota mas baja: "+taller;
        }else{}
        if (parcial<=taller && parcial<=quiz && parcial<=expocision) {
            return"parcial es la nota mas baja: "+parcial;
        }else{
            return"expocision es la nota mas baja: "+expocision;
       }
    }
    public String imprimir(){
        return "nombre y apellido del estudiante: "+nombre+
                "\nsu codigo: "+codigo+
                "\nnombre de la asignatura: "+asignatura+
                "\nsu definitiva es: "+def()+
                "\nestado de la asignatura: "+validacionnota()+
                "\n"+nota_mas_alta()+ " " +nota_mas_baja();
    }
}
