/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package METODOS;

import javax.swing.JOptionPane;

// EGERCICIO 27
public class VENDEDOR_ {
    public static void main(String[] args) {
        //declaraion de variables 
        int m,n;
       double matriz [][];  //declaracion de la matriz
       double sumacolumnas = 0,sumafila=0,sumatotal=0;
       
       n = Integer.parseInt(JOptionPane.showInputDialog("numero de vendedores")); //filas de la matriz 
       m = Integer.parseInt(JOptionPane.showInputDialog("años de la empresa"));   //columnas de la matriz
       
       matriz = new double [n][m];  //creacion de la matriz
       
       //llamar matodos
       llenarlamatriz(matriz);
        System.out.println("");
       totaldeventas(sumafila,matriz);
        System.out.println("");
       total_ventas_años(sumacolumnas,matriz);
        System.out.println("");
       ventas_compañía(sumatotal,matriz); 
    }
    public static void llenarlamatriz(double matriz [][]){
        //llenar matriz con dos for anidados
     for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length ; j++) {
                matriz[i][j]= Double.parseDouble(JOptionPane.showInputDialog("llena la matriz en la posicion "+i+j));
            }
        }   
    }
    public static void totaldeventas(double sumafila,double matriz[][]){
        //sumar filas para sacar el total de ventas del vendedor
           for (int i = 0; i < matriz.length; i++) {
            sumafila=0;
            for (int j = 0; j < matriz[i].length; j++) {
                sumafila+=matriz [i][j];
            }
            System.out.println("la suma del vendedor en la pocision "+i+" es : "+sumafila);
        }
    }
    public static void total_ventas_años(double sumacolumnas,double matriz[][]){
        //sumar columnas para sacar lo q se gano en el año
        for (int j = 0; j < matriz[0].length; j++) {
                sumacolumnas=0;
                for (int  i = 0; i < matriz.length; i++) {
                    sumacolumnas+= matriz[i][j];
                }
                System.out.println("la suma total del año de los vendedores es: "+sumacolumnas);
            }
    }
    public static void ventas_compañía(double sumatotal,double matriz[][]){
        //sumar toda la matriz 
         for ( int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[i].length; j++) {
                    sumatotal+= matriz[i][j];
                }
            }
            System.out.println("la suma total de la compañia de cada año es : "+sumatotal);
    }

}
