
package METODOS;

import javax.swing.JOptionPane;

public class PARCIAL_CANDIDATOS_MUNICIPOS {
    public static void main(String[] args) {
        String candidatos [], municipios[]; //declaracion de vectores 
        int n,m; // declaracion de variables 
        long votos [][]; //creacion de la matriz votos
        
      
        //validacion del tamaño del vector
        do {
            m= Integer.parseInt(JOptionPane.showInputDialog("digite la cantidad de candidatos: "));
        } while (m<0);
         do {
            n= Integer.parseInt(JOptionPane.showInputDialog("digite la cantidad de municipios: "));
        } while (n<0);
        
     
        candidatos = new String [m]; // creacion del vector candidatos
        municipios = new String [n]; // creacion del vector municipios
        
        votos = new long [m][n]; // creacion de la matriz
        
        //llamado de los metodos
        llenarVectores(candidatos,municipios);
        llenarMatriz (votos);
        votosCandidatos(candidatos, votos);
        votosMunicipios(municipios, votos);
        
    }
    //metodos para llenar los vectores
    public static void llenarVectores (String m[], String c[]){
        //for para llenar el vector candidatos
        for (int e = 0; e < m.length; e++) {
            m[e]=JOptionPane.showInputDialog("digite el nombre del candidato en la posicion " + e +  " : ");
            
        }
        //for para llenar el vector municipio
        for (int s = 0; s <c.length; s++) {
            c[s]=JOptionPane.showInputDialog("didgite el nombre del municipio en la posicion "  +s+ " : ");
        }
        
    }
    //metodo para llenar la matriz votos
    public static void llenarMatriz (long matriz[][]){
        //for para llenar la matriz
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                
                matriz [i][j]= Long.parseLong(JOptionPane.showInputDialog("digite los votos en la posicion [" + i  +"] [" +j + "]" ));
            }
        }
    }//metodo  para recorrer y calcular la votacion de los candidatos y el candidato con mayor votacion 
    public static void votosCandidatos(String c [], long matriz[][]){
        int suma, mayor , posicion =0;
        mayor=0;
        for (int i = 0; i < matriz.length; i++) {
            suma=0;
            for (int j = 0; j < matriz[i].length; j++) {
                suma += matriz[i][j];
                
                
            }
            JOptionPane.showMessageDialog(null,"el candidatos " + c[i] + " obtuvo la cantidad " + suma + " de votos" );
            //if para validar el candidato con mayor votacion
            if (suma>mayor) {
                mayor=suma;
                posicion = i;
            }
            
        }
        JOptionPane.showMessageDialog(null,"el candidato que obtuvo mayor votacion es: " + c[posicion]);
    }
    //metodo  para recorrer y calcular la votacion de los municipios y el municipio con mayor votacion 
    public static void votosMunicipios(String m[], long matriz[][]){
        int suma, mayor, posicion=0;
        mayor =0;
        for (int i = 0; i < matriz[0].length; i++) {
            suma=0;
            for (int j = 0; j < matriz.length; j++) {
                suma+= matriz[j][i];
                
            }
            JOptionPane.showMessageDialog(null,"el municipio " + m[i] + " obtuvo la cantidad " + suma + " de votos" );
            //if para validar el municipio con mayor votacion
             if (suma>mayor) {
                mayor=suma;
                posicion = i;
            }
        }
        JOptionPane.showMessageDialog(null,"el municipoi que realizo mas votaciones es: " + m[posicion]);
    
    }
}
