
package METODOS;
//EJERCICIO 14

import javax.swing.JOptionPane;

public class ARTICULOS {
    public static void main(String[] args) {
        //declaracion de variables 
        
        String articulo[],msg;
        int cantidad[],i,n;
        
        do{
            n=Integer.parseInt(JOptionPane.showInputDialog("dijite tamaño del vector"));
        }while(n<0);
        //creacion de vectores
        articulo  = new String [n];
        cantidad = new int [n];
        llenarvectores(articulo,cantidad);
        transaciones(articulo,cantidad);
        
        //imprimo los dos vectores
        msg="";
        for (int j = 0; j < articulo.length; j++) {
            msg += " " + articulo[j] + " - " +cantidad[j];
        }
        JOptionPane.showMessageDialog(null,msg);
    }
    
    public static void llenarvectores(String articulo[],int cantidad[]){
        for (int i = 0; i < articulo.length; i++) {
            articulo[i]=JOptionPane.showInputDialog("vector de articulos "+i);
            cantidad[i]=Integer.parseInt(JOptionPane.showInputDialog("vector de cantidad "+i));
        }
    }
    
    public static void transaciones(String articulo[],int cantidad[]){
        int tipo, can;
        String art;
        int n;
        do{
            n=Integer.parseInt(JOptionPane.showInputDialog("dijite numero de transacciones "));
        }while(n<0);
        
        
        //ciclo para realizar tres transacciones 
        for (int i = 1; i <= n; i++) {
            
            tipo = Integer.parseInt(JOptionPane.showInputDialog("1 proveedor y 2 cliente"));
            art = JOptionPane.showInputDialog("nombre del articulo");
            can = Integer.parseInt(JOptionPane.showInputDialog("cantidad transada"));
           
            
            //ciclo para recorrer los vectores
            for (int j = 0; j < articulo.length; j++) {
                if (articulo[j].equalsIgnoreCase(art)) {
                    if (tipo == 1) 
                        cantidad[j]+=can;
                    else
                        cantidad[j]-=can;
                    
                }
                
            }
        }
        
    }
    
    
}
