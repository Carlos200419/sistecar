/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MATRICES;

import javax.swing.JOptionPane;

/**
 *
 * @author Sala de Sistemas
 */
//EJERCICIO  27 
public class VENDEDORES_AÑOS {
    public static void main(String[] args) {
        int m,n;
       double matriz [][];
       double sumacolumnas,sumafila;
       
       n = Integer.parseInt(JOptionPane.showInputDialog("numero de vendedores"));
       m = Integer.parseInt(JOptionPane.showInputDialog("años de la empresa"));
       
       matriz = new double [n][m];
       int sumatotal=0;
       
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length ; j++) {
                matriz[i][j]= Double.parseDouble(JOptionPane.showInputDialog(" dijite las ventas del vendedor"));
                
            }
        }
        for (int i = 0; i < matriz.length; i++) {
            sumafila=0;
            for (int j = 0; j < matriz[i].length; j++) {
                sumafila+=matriz [i][j];
            }
            System.out.println("la suma de cada vendedor es : "+sumafila);
        }
            for (int j = 0; j < matriz.length; j++) {
                sumacolumnas=0;
                for (int  i = 0; i < matriz.length; i++) {
                    sumacolumnas+= matriz[i][j];
                }
                System.out.println("la suma total de ventas en cada año: "+sumacolumnas);
            }
            for ( int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[i].length; j++) {
                    sumatotal+= matriz[i][j];
                }
            }
            System.out.println("la suma total de la compañia de cada año es : "+sumatotal);
    }
}
        
    

